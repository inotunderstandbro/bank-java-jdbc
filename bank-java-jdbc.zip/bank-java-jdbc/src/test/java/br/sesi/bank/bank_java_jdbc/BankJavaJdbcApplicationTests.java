package br.sesi.bank.bank_java_jdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankJavaJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
