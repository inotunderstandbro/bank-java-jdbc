package br.sesi.bank.bank_java_jdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankJavaJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankJavaJdbcApplication.class, args);
	}

}
